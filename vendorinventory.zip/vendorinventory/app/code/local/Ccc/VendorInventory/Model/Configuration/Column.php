<?php

class Ccc_VendorInventory_Model_Configuration_Column extends Mage_Core_Model_Abstract
{
    protected function _construct(){
        $this->_init("vendorinventory/configuration_column");
    }
}