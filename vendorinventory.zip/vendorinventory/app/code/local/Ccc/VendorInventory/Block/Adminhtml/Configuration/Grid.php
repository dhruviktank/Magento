<?php

class Ccc_VendorInventory_Block_Adminhtml_Configuration_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
        // $this->
        $this->setTemplate('vendorinventory/configuration.phtml');
    }
}