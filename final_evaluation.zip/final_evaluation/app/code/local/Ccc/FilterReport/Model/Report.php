<?php

class Ccc_FilterReport_Model_Report extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('filterreport/report');
    }
}