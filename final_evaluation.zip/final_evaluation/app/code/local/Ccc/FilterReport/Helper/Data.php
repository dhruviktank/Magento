<?php

class Ccc_FilterReport_Helper_Data extends Mage_Core_Helper_Abstract
{

}